from shutil import move
import random
import os
import cv2
from tqdm import tqdm

# JPEGImages
src_path = "E:/CV/PascalVOC2012/VOC2012/test_color/"
dst_path = "E:/CV/PascalVOC2012/VOC2012/data/"
test_path = "E:/CV/PascalVOC2012/VOC2012/tgt_data/"
save_path = "E:/CV/PascalVOC2012/VOC2012/tgt_data_train/"

def random_move(path1,path2,num):
    path = path1
    imgs = []
    for x in os.listdir(path):
        if x.endswith('jpg'):
            imgs.append(x)
    selected_imgs = random.sample(imgs, k=num)
    # print(selected_imgs)

    for img in selected_imgs:
        src = os.path.join(path, img)
        dst = os.path.join(path2 + img)
        move(src, dst)
    print("move done")

def select_img(path,delet_path):
    cnt = 0
    for x in os.listdir(path):
        src = os.path.join(path, x)
        img = cv2.imread(src)
        if img.shape[0]<256 or img.shape[1]<256:
            cnt = cnt+1
            print(cnt)
            dst = os.path.join(delet_path + x)
            move(src, dst)

def gray_process(root,save):
    n = 1
    file_list = os.listdir(root)
    if not os.path.isdir(save):
        os.makedirs(save)
    for f in tqdm(file_list):
        rgb_img = cv2.imread(os.path.join(root, f), cv2.IMREAD_GRAYSCALE)
        cv2.imwrite(os.path.join(save, str(n) + '.jpg'), rgb_img)
        n += 1

def cut_img(path,save):
    file_list = os.listdir(path)
    n = 1
    for f in tqdm(file_list):
        img = cv2.imread(os.path.join(path, f))
        y = img.shape[0]
        x = img.shape[1]
        if x<y:
            n_y = y/x*256
            new_img = cv2.resize(img, (256, int(n_y)), interpolation=cv2.INTER_AREA)
            new_img = new_img[int(n_y / 2 - 128):int(n_y / 2 + 128), :]
        else:
            n_x = x/y*256
            new_img = cv2.resize(img, (int(n_x), 256), interpolation=cv2.INTER_AREA)
            new_img = new_img[:, int(n_x / 2 - 128):int(n_x / 2 + 128) ]
        cv2.imwrite(os.path.join(save, str(n) + '.jpg'), new_img)
        n = n+1

# random_move(src_path,dst_path,27)
# select_img(src_path,dst_path)
# gray_process(src_path,src_path)
cut_img(test_path,save_path)
